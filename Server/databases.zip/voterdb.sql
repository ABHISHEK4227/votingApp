-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2020 at 07:53 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voterdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `photographs`
--

CREATE TABLE `photographs` (
  `EPIC` varchar(50) NOT NULL,
  `IMAGE` varchar(15000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE `voter` (
  `EPIC` varchar(50) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `FATHER_NAME` varchar(255) NOT NULL,
  `DOB` varchar(10) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `SEX` varchar(7) NOT NULL,
  `CID` varchar(50) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`EPIC`, `NAME`, `FATHER_NAME`, `DOB`, `ADDRESS`, `SEX`, `CID`, `PASSWORD`) VALUES
('BKA5528102', 'Arnab Kumar Basu', 'Father Basu', '02/04/1988', 'Sector 1, Saltlake, North 24 Parganas, West Bengal 700066', 'Male', '123', '123'),
('CHA1357901', 'Arunava Chakraborty', 'Father Chakraborty', '01/12/1993', 'Newtown, Saltlake, North 24 Parganas, West Bengal 701034', 'Male', '321', '123'),
('GDN0225185', 'Gamora', 'Thanos', '01/12/1980', 'Space, Whole Universe', 'Female', '111', '12345'),
('MAS1735128', 'Swapnil Mallick', 'Father Mallick', '01/03/1987', 'Acropolis, Ruby, Kolkata, West Bengal, 700065', 'Gorilla', '111', '123'),
('MUA4562113', 'Abhishek Mukherjee', 'Father Mukherjee', '01/02/1999', 'South Garia, Kolkata, West Bengal, 700123', 'Male', '321', '123'),
('PAA8509112', 'Ankur Paul', 'Father Paul', '01/02/1998', '8B Bus Stand, Jadavpur, Kolkata, West Bengal, 700012', 'Male', '123', '123'),
('ROR9914721', 'Ranajit Roy', 'Father Roy', '04/10/1991', 'Baguiati, Dumdum, North 24 Parganas, West Bengal 701022', 'Male', '111', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photographs`
--
ALTER TABLE `photographs`
  ADD PRIMARY KEY (`EPIC`);

--
-- Indexes for table `voter`
--
ALTER TABLE `voter`
  ADD PRIMARY KEY (`EPIC`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
